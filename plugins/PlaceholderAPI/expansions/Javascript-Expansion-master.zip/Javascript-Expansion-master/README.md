# Javascript-Expansion
Adds javascript placeholders
[![Build Status](http://ci.extendedclip.com/buildStatus/icon?job=Javascript-Expansion)](http://ci.extendedclip.com/job/Javascript-Expansion/)