function hp() {
  return Math.round(parseInt('%player_health%') * 100) / 100;
}
hp();