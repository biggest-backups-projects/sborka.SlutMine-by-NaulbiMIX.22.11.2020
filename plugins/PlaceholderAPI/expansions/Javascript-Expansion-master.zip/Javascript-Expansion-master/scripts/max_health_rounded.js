function hp() {
  return Math.round(parseInt('%player_max_health%') * 100) / 100;
}
hp();